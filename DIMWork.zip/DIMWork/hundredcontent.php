<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Hundred Year War</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>
  <!-- This is the php to include the nav bar -->
  <?php include('includes/nav.php') ?>

  <header>
    <!-- Full Page Intro -->
    <div id="intro-section" class="view">

      <!-- Mask & flexbox options-->
      <div class="mask rgba-gradient d-flex justify-content-center align-items-center">

        <!-- Content -->
        <div class="container px-md-3 px-sm-0">

          <!--Grid row-->
          <div class="row wow fadeIn">

            <div class="row">

              <!-- Grid column -->
              <div class="col-md-6 mb-4">

                <!--Card-->
                <div class="card elegant-color">

                  <!--Card image-->
                  <div class="view">

                  </div>
                  <!--Card content-->
                  <div class="card-body text-center">
                    <!--Title-->
                    <h4 class="card-title yellow-text">BackStory, Key Dates And Facts</h4>
                    <!--Text-->
                    <p class="card-text white-text">What was it: the Hundred Years' War was a long struggle between England and France over succession to the French throne </p>
                    <p class="card-text white-text">Dates: The War lasted from 1337 to 1453, so really it should, more accurately, be called the "116 YearsW War </p>
                    <p class="card-text white-text"> What major battles were there?: Battle of sluys, Battle of Crecy, Battle of Calais, Battle of Aurway, Battle of Rochelle. </p>
                    <p class="card-text white-text"> What Caused it?: The English King, Edward III, claimed he was the King of England that really started the War. But there were many other factors such as the land around france that the English contested and the Wool Trade that came with those lands and bordering seas. </p>
                  </div>
                </div>
                <!--/.Card-->

              </div>
              <!-- Grid column -->

              <!-- Grid column -->
              <div class="col-md-6 mb-4">

                <!--Card-->
                <div class="card elegant-color">

                  <!--Card image-->
                  <div class="view">
                  </div>

                  <!--Card content-->
                  <div class="card-body text-center">
                    <!--Title-->
                    <h4 class="card-title yellow-text">The Battles?</h4>
                    <!--Text-->
                    <p class="card-text white-text">The war starts off with several stunning successes on Britain's part, and the English forces dominate France for decades. Then, the struggle see-saws back and forth. In the 1360s, the French are winning. From 1415-1422, the English are winning. After 1415, King Henry V of England revives the campaign and he conquers large portions of France, winning extraordinary political concessions. From 1422 onward, however, the French crown strikes back. The teenage girl Jeanne d'Arc (Joan of Arc), a remarkable young mystic, leads the French troops to reclaim their lands. The English lose most of its lands in France so arguably they did lose. </p>
                    <p class="card-text white-text"> Joan Of Arc
                    Nicknamed "The Maid of Orléans," was born in 1412 in Domrémy, Bar, France. A national heroine of France, at age 18 she led the French army to victory over the English at Orléans. Captured a year later, Joan was burned at the stake as a heretic by the English and their French collaborators. She was canonized as a Roman Catholic saint more than 500 years later, on May 16, 1920. </p>

                  </div>

                </div>
                <!--/.Card-->


              </div>
              <!-- Grid column -->

            </div>
            <!-- Grid row -->
            <a href="hundredyearquiz.php" button type="button" class="btn btn-rounded btn-outline-yellow waves-effect waves-light">Take The Quiz</a>
          </div>
          <!--Grid column-->

        </div>
        <!--Grid row -->

      </div>
      <!-- Content -->

    </div>
    <!-- Mask & flexbox options-->


    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <script type="text/javascript" src="js/warmup.js"></script>
</body>
</header>

</html>
