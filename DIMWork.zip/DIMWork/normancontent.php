<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Norman Quiz</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body>
  <!-- This is the php to include the nav bar -->
  <?php include('includes/nav.php') ?>

  <header>
    <!-- Full Page Intro -->
    <div id="intro-section" class="view">

      <!-- Mask & flexbox options-->
      <div class="mask rgba-gradient d-flex justify-content-center align-items-center">

        <!-- Content -->
        <div class="container px-md-3 px-sm-0">

          <!--Grid row-->
          <div class="row wow fadeIn">

            <div class="row">

              <!-- Grid column -->
              <div class="col-md-6 mb-4">

                <!--Card-->
                <div class="card elegant-color">

                  <!--Card image-->
                  <div class="view">

                  </div>
                  <!--Card content-->
                  <div class="card-body text-center">
                    <!--Title-->
                    <h4 class="card-title yellow-text">BackStory, Key Dates And Facts</h4>
                    <!--Text-->
                    <p class="card-text white-text">When Edward the Confessor died, Harold Godwinson, Earl of Wessex, was immediately crowned king and became Harold II. The royal council, known as the Witan, supported him. He gathered an army to
                      defend the kingdom. </p>
                    <p class="card-text yellow-text"> Start Date: 1066. </p>
                    <p class="card-text white-text"> Who Won?: William was crowned king of England on Christmas Day 1066, but it took years more fighting to conquer the whole country. His cruellest campaign was the 'Harrying of the North' in 1069,
                      where he slaughtered the inhabitants of the north-east and destroyed their food stores, starving the rebels to death. </p>
                    <p class="card-text white-text"> What major battles were there?: Battle of Stamford Bridge, Known as the end of the viking age. Battle of Hastings, William vs Harold Godwinson known for Harold dying to an arrow that was shot into
                      his eye. </p>
                    <p class="card-text white-text"> What were the Army Sizes?: 15000 Norman troops vs 5000 Saxon troops vs 8000 Vikings </p>
                  </div>
                </div>
                <!--/.Card-->

              </div>
              <!-- Grid column -->

              <!-- Grid column -->
              <div class="col-md-6 mb-4">

                <!--Card-->
                <div class="card elegant-color">

                  <!--Card image-->
                  <div class="view">
                  </div>

                  <!--Card content-->
                  <div class="card-body text-center">
                    <!--Title-->
                    <h4 class="card-title yellow-text">What was the Leaders Claims to the throne?</h4>
                    <!--Text-->
                    <p class="card-text white-text">Harold Godwinson, Earl of Wessex
                      Harold was a powerful and rich English nobleman. According to the Anglo-Saxon Chronicle, Edward named Godwinson as his successor on his deathbed. The next day, the royal council, known as the Witan, met and declared Godwinson
                      king. An English king was proclaimed by the Witan - this gave Harold Godwinson the only claim to the throne by right. </p>

                    <p class="card-text white-text"> William, Duke of Normandy
                      The Norman chroniclers reported that Edward had promised his distant relative, William, the throne in 1051. William was the only blood relative of Edward, but the English throne was not hereditary anyway. Claims that Edward
                      promised the throne were probably made up by the rival sides after the event. The Bayeux Tapestry, which was made after the Conquest, shows Godwinson swearing an oath of support to William in a visit to Normandy in 1064.
                      William was supported by the Pope. </p>

                    <p class="card-text white-text"> Harald Hardrada, King of Norway, Viking warrior
                      Hardrada based his claim on the fact that his ancestor, King Cnut, had once ruled England (1016‒1035). He was helped by Godwinson's half-brother, Tostig.</p>
                  </div>

                </div>
                <!--/.Card-->


              </div>
              <!-- Grid column -->

            </div>
            <!-- Grid row -->
            <a href="normanquiz.php" button type="button" class="btn btn-rounded btn-outline-yellow waves-effect waves-light">Take The Quiz</a>
          </div>
          <!--Grid column-->

        </div>
        <!--Grid row -->

      </div>
      <!-- Content -->

    </div>
    <!-- Mask & flexbox options-->


    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <script type="text/javascript" src="js/warmup.js"></script>
</body>
</header>

</html>
